You can run it on your PC It's safe

I recommend that you do not run them all at the same time as it will be difficult for you to finish the processes

don't go making the mistake that I did of executing all of them at the same time
send the PC to the floor ok no. just restart it :D